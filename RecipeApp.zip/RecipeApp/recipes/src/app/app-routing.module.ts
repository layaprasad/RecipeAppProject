import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NewrecipeComponent } from './newrecipe/newrecipe.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { RecipelistComponent } from './recipelist/recipelist.component';
import { UpdateComponent } from './update/update.component';
import { FullrecipeComponent } from './fullrecipe/fullrecipe.component';
import { MyrecipeComponent } from './myrecipe/myrecipe.component';
import { UserGuard } from './user.guard'


const routes: Routes = [
  {path: '' , redirectTo:'home', pathMatch:'full'},
  {path: 'home' , component:HomeComponent},
  {path: 'recipes' , component:RecipelistComponent},
  {path: 'add' , component:NewrecipeComponent, canActivate:[UserGuard]},
  {path: 'login' , component:LoginComponent},
  {path: 'register' , component:RegisterComponent},
  {path: 'full/:id' , component:FullrecipeComponent},
  {path: 'myrecipe' , component:MyrecipeComponent, canActivate:[UserGuard]},
  {path: 'update/:id' , component:UpdateComponent, canActivate:[UserGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
