import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RecipeModel } from '../recipelist/recipe.model';
import { RecipeServiceService } from '../recipe-service.service';
import { ActivatedRoute,ParamMap } from '@angular/router';
import { SafeResourceUrl } from '@angular/platform-browser';


@Component({
  selector: 'app-fullrecipe',
  templateUrl: './fullrecipe.component.html',
  styleUrls: ['./fullrecipe.component.css']
})
export class FullrecipeComponent implements OnInit {
  title:String = "Detailed Recipe";  
  recipes : RecipeModel[] ;
  id:string;
  productItem:any;
  singleproduct:any;
  mode:string;
  // photoUrl: SafeResourceUrl;
  // apiUrl : "http://localhost:3000";

  constructor( private router: Router, private RecipeService : RecipeServiceService,private activeRoute: ActivatedRoute) { }

  ngOnInit(): void {
    
      this.activeRoute.paramMap.subscribe((paramMap: ParamMap) => {
      if(paramMap.has('id')){
        this. id = paramMap.get('id'); 
        console.log(this.id);
        this.RecipeService.getfullRecipes(this.id).subscribe(recipe => {
          this.singleproduct = JSON.parse(JSON.stringify(recipe));
          // this.photoUrl = this.singleproduct.bypassSecurityTrustResourceUrl(`${this.apiUrl}/public/image`);
         
          const {
            title,
            category,
            description,
            image, 
            ingredients,
            directions,
            servings,
            video,
            time,
            difficulty,
            rate} = this.singleproduct; 
            console.log(this.singleproduct);
   
          this.productItem=new RecipeModel(
            title, 
            category, 
            description, 
            image, 
            ingredients, 
            directions, 
            servings, 
            video,
            time,
            difficulty,
            rate)
           console.log(this.productItem)
        })
      }
    }) 
  }

  // goback(){
  //   this.router.navigate(['/recipes']);
  // }
}

//photoUrl: SafeResourceUrl;
// ngOnInit() {
//   this.urlService.siteProfile.subscribe(s => {
//     this.siteProfile = s;
//     if(s != null) {
//       this.photoUrl = this.sanitizer.bypassSecurityTrustResourceUrl(`${this.apiUrl}/image-directory/your-pic?id`);
//     }
//   });

  // getfullRecipes(){
  //   this.RecipeService.getfullRecipes()
  //   .subscribe((data)=>{
  //     this.recipes=JSON.parse(JSON.stringify(data));
  //   })
  // }


