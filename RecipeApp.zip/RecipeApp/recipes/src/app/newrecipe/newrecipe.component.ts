import { Component, OnInit } from '@angular/core';
import { RecipeServiceService } from '../recipe-service.service';
import { RecipeModel } from '../recipelist/recipe.model';
import { Router } from '@angular/router';
import { FormGroup,Validators,FormBuilder,FormControl, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpEvent, HttpEventType } from '@angular/common/http';


@Component({
  selector: 'app-newrecipe',
  templateUrl: './newrecipe.component.html',
  styleUrls: ['./newrecipe.component.css']
})
export class NewrecipeComponent implements OnInit {
  title: String ="Add recipe";
  preview: string;
  // form: FormGroup;
  // percentDone: any = 0;
  // recipes = [];
  percentDone: any =1;
    // recipeItem = new RecipeModel(null,null,null,null,null,null,null,null,null,null,null);

  constructor( public recipeService : RecipeServiceService, public fb: FormBuilder ,private router : Router) { }

    form : FormGroup   = this.fb.group({          
      title : ['', Validators.required],
      category : ['', Validators.required],
      description : ['', Validators.required],
      image : [null, Validators.required],
      ingredients : ['', Validators.required],
      directions : ['', Validators.required],
      servings : ['', Validators.required],
      video : ['', Validators.required],
      time : ['', Validators.required],
      difficulty : ['', Validators.required],
      rate : ['', Validators.required]
  });

  ngOnInit() {
  }

  // Image Preview
  selectImage(event){
    const file = (event.target as HTMLInputElement).files[0];
    this.form.patchValue({image: file });
    this.form.get('image').updateValueAndValidity()
    // File Preview
    const reader = new FileReader();
    reader.onload = () => {
      this.preview = reader.result as string;
    }
    reader.readAsDataURL(file)
  }
  // console.log(this.form.value);

  newRecipe(){
    if(this.form.valid){
      this.recipeService.newRecipe(this.form.value.title,this.form.value.category,this.form.value.description,this.form.value.ingredients,this.form.value.directions,this.form.value.servings,this.form.value.video,this.form.value.time,this.form.value.difficulty,this.form.value.rate,this.form.value.image)
      .subscribe((event:HttpEvent<any> ) =>{
        switch (event.type){
          case HttpEventType.Sent:
              console.log('Request has been made!');
              break;  
          case HttpEventType.ResponseHeader:
              console.log('Response header has been received!');
              break;
          case HttpEventType.UploadProgress:
              this.percentDone = Math.round(event.loaded / event.total * 100);
              console.log(`Uploaded! ${this.percentDone}%`);
              break;
          case HttpEventType.Response:           
              console.log('Recipe successfully added!', + event.body);
              this.percentDone = false;
             
        }this.router.navigate(['/myrecipe']); 
      })
    } 
  } 
}
// this.recipeService.newRecipe(this.recipeItem);
    // alert("success");
    // this.router.navigate(['/recipes']);