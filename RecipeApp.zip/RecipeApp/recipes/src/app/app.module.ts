import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule  , HTTP_INTERCEPTORS} from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { UserGuard } from './user.guard';
import { TokenInterceptorService } from './token-interceptor.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { NewrecipeComponent } from './newrecipe/newrecipe.component';
import { RecipelistComponent } from './recipelist/recipelist.component';
import { MyrecipeComponent } from './myrecipe/myrecipe.component';
import { FullrecipeComponent } from './fullrecipe/fullrecipe.component';
import { UpdateComponent } from './update/update.component';
import { UserService } from './user.service';
import { RecipeServiceService } from './recipe-service.service';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegisterComponent,
    LoginComponent,
    NewrecipeComponent,
    RecipelistComponent,
    MyrecipeComponent,
    FullrecipeComponent,
    UpdateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [UserGuard,UserService,RecipeServiceService,
  {
    provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptorService,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
