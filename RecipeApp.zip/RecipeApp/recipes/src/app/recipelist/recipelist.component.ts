import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RecipeModel } from './recipe.model';
import { RecipeServiceService } from '../recipe-service.service';

@Component({
  selector: 'app-recipelist',
  templateUrl: './recipelist.component.html',
  styleUrls: ['./recipelist.component.css']
})
export class RecipelistComponent implements OnInit {
  title:String = "Recipes";  
  recipes : RecipeModel[] ;
  id:string;


  constructor( private router: Router, private RecipeService : RecipeServiceService) { }


  ngOnInit(): void {
    this.getRecipes();
  }
  getRecipes(){
    this.RecipeService.getRecipes()
    .subscribe((data)=>{
      this.recipes=JSON.parse(JSON.stringify(data));
    })
  }

}
