export class MyrecipeModel{
    _id ?: string;
    constructor(
        public title : String,
        public category : String,
        public description : String,
        public image : String,
        public ingredients : String,
        public directions : String,  
        public servings : Number, 
        public video : String, 
        public time : String,
        public difficulty : String,
        public rate : Number ){}
}