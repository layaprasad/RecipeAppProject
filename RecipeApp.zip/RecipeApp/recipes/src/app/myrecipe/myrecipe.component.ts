import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RecipeModel } from '../recipelist/recipe.model';
import { RecipeServiceService } from '../recipe-service.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-myrecipe',
  templateUrl: './myrecipe.component.html',
  styleUrls: ['./myrecipe.component.css']
})
export class MyrecipeComponent implements OnInit {
  title:String = "Recipes";  
  recipes : RecipeModel[] ;
  id:string;

  constructor(private router: Router, private RecipeService : RecipeServiceService) { }

  ngOnInit(): void {
    this.getMyRecipes();
  }
  getMyRecipes(){
    this.RecipeService.getMyRecipes()
    .subscribe((data)=>{
      this.recipes=JSON.parse(JSON.stringify(data));
    },
    err => {
      if( err instanceof HttpErrorResponse){
        if(err.status === 401){
          this.router.navigate(['/login']);
        }
      }
    }
    )
  }
}
