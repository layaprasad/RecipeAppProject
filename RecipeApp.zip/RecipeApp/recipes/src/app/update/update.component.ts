import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RecipeModel } from '../recipelist/recipe.model';
import { MyrecipeModel } from '../myrecipe/myrecipe.model';

import { RecipeServiceService } from '../recipe-service.service';
import { ActivatedRoute,ParamMap } from '@angular/router';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  title:String = "Detailed Recipe";  
  recipes : RecipeModel[] ;
  id:string;
  productItem:any;
  singleproduct:any;
  mode:string;


  constructor(private router: Router, private RecipeService : RecipeServiceService,private activeRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.activeRoute.paramMap.subscribe((paramMap: ParamMap) => {
      if(paramMap.has('id')){
        this. mode =`update`;
        // console.log(this. mode)
        this. id = paramMap.get('id'); 
        // this.isLoading = true;
        this.RecipeService.editRecipe(this.id).subscribe(recipe => {
          this.singleproduct = JSON.parse(JSON.stringify(recipe));  
          console.log(this.id);       
          console.log(this.singleproduct);
          const {
            title,
            category,
            description,
            image,
            ingredients,
            directions,
            servings,
            video,
            time,
            difficulty,
            rate} = this.singleproduct; 
            console.log(this.singleproduct);
   
          this.productItem=new RecipeModel(
            title, 
            category, 
            description, 
            image, 
            ingredients, 
            directions, 
            servings, 
            video,
            time,
            difficulty,
            rate)
           console.log(this.productItem)
        })
      }
    }) 
  }
  updateRecipe(){ 
    this.RecipeService.updateRecipe(this.productItem, this.id);
    console.log(this.productItem);
    this.router.navigate(['/myrecipe']); 
    }   

  deleteRecipe(id){
    this.RecipeService.deleteRecipe(id).subscribe(result => {
    this.router.navigate(['/myrecipe']);
    // this.RecipeService.getRecipes()
    }, error => console.log('There was an error: ', error));
  }

}
