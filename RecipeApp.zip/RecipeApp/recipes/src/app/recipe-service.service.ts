import { Injectable } from '@angular/core';
import { HttpHeaders, HttpErrorResponse, HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class RecipeServiceService {

  id:string;
  percentDone:  any;
  constructor( private http: HttpClient) { }
  getRecipes(){
    return this.http.get("http://localhost:3000/recipes");
  }

  getfullRecipes(id){
    return this.http.get<any>(`http://localhost:3000/full/${id}`);
  }

  getMyRecipes(){
    return this.http.get("http://localhost:3000/myrecipes");
  }

  editRecipe(id){
    return this.http.get<any>(`http://localhost:3000/edit/${id}`);
  }

  updateRecipe(item,id){
    return this.http.put(`http://localhost:3000/update`,{"recipe":item , id:id})
    .subscribe((data) => {console.log('Updated Recipe',data);
  });
  }

  deleteRecipe(id){
    return this.http.post("http://localhost:3000/delete", {id:id});
  }

  // newRecipe(item , image){
  //   return this.http.post("http://localhost:3000/insert" , {"recipe":item, "image": image})
  //   .subscribe(data => {console.log(data)})
  // }  return this.http.post<User>(`${this.baseURL}/insert`, formData, {

  newRecipe(title : String,
    category : String,
    description : String,  
    ingredients : String,
    directions : String,  
    servings : Number, 
    video : String,
    time : String,  
    difficulty : String,
    rate : Number , profileImage: File): Observable<any> {
    var formData: any = new FormData();
        formData.append("title", title);
        formData.append("category", category);
        formData.append("description", description);
        formData.append("ingredients", ingredients);
        formData.append("directions", directions);
        formData.append("servings", servings);
        formData.append("video", video);
        formData.append("time", time);
        formData.append("difficulty", difficulty);
        formData.append("rate", rate);
        formData.append("image", profileImage);

    return this.http.post<any>(`http://localhost:3000/insert`, formData, {
      reportProgress: true,
      observe: 'events'
    })
  }

}
