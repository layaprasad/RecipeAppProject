import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  title : String = "Login";
  loginUserDetails={
    "email" :""  ,
    "password" : ""
  };

  constructor(private userservice:UserService, private router:Router) { }

  loginUser(){
    this.userservice.loginUser(this.loginUserDetails) 
        .subscribe(
          res=>{
              const tok = res['token'];
              console.log(res);
              localStorage.setItem('token' , tok)
              this.router.navigate(['/myrecipe'])           
          },
          err=>console.log(err))
  }
  ngOnInit(): void {
  }

}
// console.log("Login");
        // alert("success"); 