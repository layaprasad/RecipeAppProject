
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/RecipeDb');
const Schema = mongoose.Schema; 

const recipeSchema =new Schema({
    title : String,
    category : String,
    description : String,
    image : String,
    ingredients : String,
    directions : String,  
    servings : Number, 
    video : String,
    time : String,  
    difficulty : String,
    rate : Number
});

var recipe = mongoose.model('recipe', recipeSchema);
module.exports = recipe;