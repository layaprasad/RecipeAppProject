
const express = require('express');
const Userdata = require('./src/models/Userdata');
const Recipedata = require('./src/models/Recipedata');
const bodyparser = require('body-parser');
const multer = require('multer');
const fs = require('fs');
const jwt = require('jsonwebtoken');

const cors = require('cors');
const port = 3000;
const app = new express();

app.use(bodyparser.json());
app.use(cors());

// Multer File upload settings
const DIR = './public/';
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, DIR);
  },
  filename: (req, file, cb) => {
    const fileName = file.originalname.toLowerCase().split(' ').join('-');
    cb(null, fileName)
  }
});
// Multer Mime Type Validation
var upload = multer({
  storage: storage,
  limits: {
    fileSize: 1024 * 1024 * 5
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
      cb(null, true);
    } else {
      cb(null, false);
      return cb(new Error('Only .png, .jpg and .jpeg format allowed!'));
    }
  }
});


app.get('/home',function(req,res){
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
});

app.get('/recipes', (req,res)=>{
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    Recipedata.find()
        .then(function(recipes){
            res.send(recipes);
        });
});

function verifyToken(req, res, next) {
    if(!req.headers.authorization) {
        return res.status(401).send('Unauthorized request')
    }
    let token = req.headers.authorization.split(' ')[1]
    if(token === 'null') {
        return res.status(401).send('Unauthorized request')      
    }
    let payload = jwt.verify(token, 'secretKey') 
    if(!payload){
        return res.status(401).send('Unauthorized request')
    }
    req.userId = payload.subject;
    next()
}

app.post('/register', function(req,res) {
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    let userData = req.body;
    let user = new Userdata(userData);
    user.save((err , registeredUser) => {
        if(err){
            console.log(err);
        } else {
            let payload = {subject: user._id};
            let token = jwt.sign(payload , 'secretKey');
            res.status(200).send({token});
        }
    })
})

app.post('/login', function(req,res) {
    let userData = req.body;
    Userdata.findOne({email: userData.email},(err, user) => {
        if(err){
            console.log(err);
        } else {
            if(!user) {                 
                res.status(401).send('Invalid Email');
            } else {
                if(user.password !== userData.password){
                    res.status(401).send('Invalid Password')
                } else {
                    let payload = {subject: user._id};
                    let token = jwt.sign(payload , 'secretKey');
                    res.status(200).send({token});
                }
            }
        }
    })
})

app.get('/full/:id', (req,res)=>{
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    const id = req.params.id;
    // const fileName = req.params.image;
    console.log(id);
    Recipedata.findById( req.params.id ,function (err , recipe){
        res.send(recipe);
        });
});

app.get('/myrecipes',verifyToken , (req,res)=>{
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    Recipedata.find()
        .then(function(recipes){
            res.send(recipes);
        });
});

app.get('/edit/:id', (req,res)=>{
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    const id = req.params.id;
    console.log(id);
    Recipedata.findById( req.params.id , function (err , recipe){
        res.send(recipe);
        });
});


app.put('/update', function(req,res){
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");  
    // console.log(req.body);
    const recipe = {
        title : req.body.recipe.title,
        category : req.body.recipe.category,
        description : req.body.recipe.description,
        image : req.body.recipe.image,
        ingredients : req.body.recipe.ingredients,
        directions : req.body.recipe.directions,
        servings : req.body.recipe.servings,
        video : req.body.recipe.video,
        time : req.body.recipe.time,
        difficulty : req.body.recipe.difficulty,
        rate : req.body.recipe.rate
    }
    
    Recipedata.findByIdAndUpdate(req.body.id,recipe)
        .then(()=>{
            console.log('Updated Successfully');
            res.send(recipe);
        })    
    .catch((err)=>{
        console.log("Update failed:" , err);
        res.send({error:err});
    })
})

app.post('/delete', function(req,res){
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");  
    console.log(req.body);
    // console.log("Id is", req.body.id);
    Recipedata.findByIdAndDelete(req.body.id)
        .then(function(recipe)
        {
            console.log("success");
            res.send(recipe);
        });     
});

app.post('/insert' ,  upload.single('image'), function(req,res,next){
    res.header("Access-Control-Allow-Orgin", "*")
    res.header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS");
    const url = req.protocol + '://' + req.get('host')   ;
    console.log(req.body);
    var recipe = new Recipedata({
        title : req.body.title,
        category : req.body.category,
        description : req.body.description,
        image : url + '/public/' + req.file.filename,
        ingredients : req.body.ingredients,
        directions : req.body.directions,
        servings : req.body.servings,
        video : req.body.video,
        time : req.body.time,
        difficulty : req.body.difficulty,
        rate : req.body.rate
    });
    // var recipe = new Recipedata(recipe);
    recipe.save();
});

app.listen(port, function(){
    console.log("Server running on localhost:",+port);
});